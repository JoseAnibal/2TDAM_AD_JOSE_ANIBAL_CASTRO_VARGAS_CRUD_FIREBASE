package com.example.pokerating

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*
import java.util.concurrent.CountDownLatch

class EditarPoke : AppCompatActivity() {

    lateinit var guardar:Button
    lateinit var atras:Button
    lateinit var edit_nombre:TextInputEditText
    lateinit var edit_tipo:TextInputEditText
    lateinit var edit_numero:TextInputEditText
    lateinit var edit_rating:RatingBar
    lateinit var edit_imagen:ImageView
    var url_imagen:Uri?=null
    lateinit var objeto_editar:pokemon

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editar_poke)
    }

    override fun onStart() {
        super.onStart()

        guardar=findViewById(R.id.edit_guardar)
        atras=findViewById(R.id.edit_atras)
        edit_nombre=findViewById(R.id.edit_nombre)
        edit_tipo=findViewById(R.id.edit_tipo)
        edit_numero=findViewById(R.id.edit_numPoke)
        edit_rating=findViewById(R.id.edit_rating)
        edit_imagen=findViewById(R.id.edit_imagen)

        objeto_editar=intent.getSerializableExtra("pasoPokemon") as pokemon

        edit_nombre.setText(objeto_editar.nombre.toString())
        edit_tipo.setText(objeto_editar.desc.toString())
        edit_numero.setText(objeto_editar.num_poke.toString())
        edit_rating.rating=objeto_editar.rating.toString().toFloat()

        Glide.with(applicationContext).load(objeto_editar.url_imagen).into(edit_imagen)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        edit_imagen.setOnClickListener {
            obtener_url.launch("image/*")
        }

        atras.setOnClickListener {
            val intent=Intent(applicationContext,verPoke::class.java)
            startActivity(intent)
        }

        guardar.setOnClickListener {

            if(edit_nombre.text.toString().trim().equals("") ||
                edit_tipo.toString().trim().equals("") ||
                edit_numero.text.toString().trim().equals("")){

                Toast.makeText(applicationContext, "No has rellenado todo", Toast.LENGTH_SHORT).show()
            }else if(edit_nombre.text.toString().trim().equals(objeto_editar.nombre.toString()) &&
                edit_tipo.text.toString().trim().equals(objeto_editar.desc.toString()) &&
                edit_numero.text.toString().toInt()==objeto_editar.num_poke!!.toInt() &&
                    edit_rating.rating==objeto_editar.rating!!.toFloat()){

                Toast.makeText(applicationContext, "No has modificado nada", Toast.LENGTH_SHORT).show()
            }else{

                var url_escudo_firebase=objeto_editar.url_imagen

                GlobalScope.launch(Dispatchers.IO) {

                    if(!edit_nombre.text.toString().trim().equals(objeto_editar.nombre) && compruebo_si_existe(edit_nombre.text.toString().trim())){
                        tostadaCorrutina("Pokemon ya existente!")
                    }else{
                        if(url_imagen!=null){
                            url_escudo_firebase=editoImagen(objeto_editar.url_imagen!!, url_imagen!!)
                        }

                        val cal= Calendar.getInstance()
                        val hoy = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)+1}-${cal.get(
                            Calendar.DAY_OF_MONTH)}"

                        editarPoke(objeto_editar.id!!,edit_nombre.text.toString().trim(),
                        edit_tipo.text.toString().trim(),
                        edit_numero.text.toString().toInt(),
                        edit_rating.rating.toDouble(),
                        hoy,url_escudo_firebase!!)

                        tostadaCorrutina("Poke: ${edit_nombre.text} modificado!")

                        val vuelvoaMain=Intent(applicationContext,MainActivity::class.java)
                        startActivity(vuelvoaMain)

                    }

                }
            }

        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent=Intent(applicationContext,verPoke::class.java)
        startActivity(intent)
    }

    private suspend fun editoImagen(id:String,foto:Uri):String{

        lateinit var urlImagenFirebase:Uri

        urlImagenFirebase= sto_ref.child("Imagenes").child("Pokedex").child(id)
            .putFile(foto).await().storage.downloadUrl.await()

        return urlImagenFirebase.toString()

    }

    fun compruebo_si_existe(nombre:String):Boolean{
        var existe=false
        val semaforo= CountDownLatch(1)

        db_ref.child("Pokemons").child("Pokedex").orderByChild("nombre").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }

    fun editarPoke(id:String,nombre:String,desc:String,num_poke:Int,rating:Double,fecha:String,url_imagen:String){
        val creo_poke=pokemon(id,nombre,desc,num_poke,rating,fecha,url_imagen)

        db_ref.child("Pokemons").child("Pokedex").child(id).setValue(creo_poke)

    }

    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri: Uri?->
        when (uri){
            null-> Toast.makeText(applicationContext,"No has seleccionado ninguna imagen", Toast.LENGTH_SHORT).show()
            else->{
                url_imagen=uri
                edit_imagen.setImageURI(url_imagen)
                Toast.makeText(applicationContext,"Imagen seleccionada", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //-------HACER UN TOAST EN UNA CORRUTINA--------------
    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(applicationContext,texto,Toast.LENGTH_SHORT).show()
        }
    }
    //------------------------------------------------------

}