package com.example.pokerating

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var crear:Button
    lateinit var ver:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()

        crear=findViewById(R.id.main_btn_crear)
        ver=findViewById(R.id.main_btn_ver)

        crear.setOnClickListener {
            val intent=Intent(this,crearPoke::class.java)
            startActivity(intent)
        }

        ver.setOnClickListener {
            val intent=Intent(this,verPoke::class.java)
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        finish()
        val intent:Intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)

    }

}