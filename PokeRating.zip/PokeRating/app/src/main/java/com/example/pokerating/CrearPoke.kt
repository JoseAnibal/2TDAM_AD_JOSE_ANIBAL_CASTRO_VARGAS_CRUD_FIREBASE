package com.example.pokerating

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.Serializable
import java.net.URI
import java.sql.DatabaseMetaData
import java.sql.Date
import java.util.*
import java.util.concurrent.CountDownLatch




lateinit var db_ref:DatabaseReference
lateinit var sto_ref: StorageReference

data class pokemon(val id:String?=null,val nombre:String?=null,val desc:String?=null,val num_poke:Int?=null,val rating:Double?=0.0,val fecha:String?=null,val url_imagen:String?=null):Serializable

class crearPoke : AppCompatActivity() {

    lateinit var nombre:TextInputEditText
    lateinit var tipo:TextInputEditText
    lateinit var num_poke:TextInputEditText
    lateinit var rating: RatingBar

    lateinit var imagen:ImageView
    lateinit var insertar:Button
    var url_imagen:Uri?=null


    val Pokemons="Pokemons"
    val Pokedex="Pokedex"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_poke)
    }

    override fun onStart() {
        super.onStart()

        nombre=findViewById(R.id.crear_tiet_nombre)
        tipo=findViewById(R.id.crear_tiet_tipo)
        num_poke=findViewById(R.id.crear_tiet_num)
        rating=findViewById(R.id.crear_rating)

        imagen=findViewById(R.id.crear_iv)
        insertar=findViewById(R.id.crear_btn_insertar)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        insertar.setOnClickListener {

            if(nombre.text.toString().trim().equals("") ||
                tipo.text.toString().trim().equals("") ||
                num_poke.text.toString().trim().equals("")){

                Toast.makeText(applicationContext, "No has rellenado todo", Toast.LENGTH_SHORT).show()
            }else if(url_imagen==null){
                Toast.makeText(applicationContext, "No has seleccionado ninguna imagen!", Toast.LENGTH_SHORT).show()
            }else{
                GlobalScope.launch(Dispatchers.IO) {

                    if(compruebo_si_existe(nombre.text.toString().trim())){
                        tostadaCorrutina("Este Pokemon ya existe")
                    }else{
                        val genero_id= db_ref.child(Pokemons).child(Pokedex).push().key
                        val url_imagen_firebase=insertoImagen(genero_id!!, url_imagen!!)

                        var ins_nombre=nombre.text.toString()
                        var ins_desc=tipo.text.toString()
                        var ins_num= num_poke.text.toString().toInt()
                        var ins_rating= rating.rating.toDouble()

                        val cal= Calendar.getInstance()
                        val hoy = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)+1}-${cal.get(Calendar.DAY_OF_MONTH)}"

                        insertoPokeid(genero_id!!,ins_nombre,ins_desc,ins_num,ins_rating,hoy,url_imagen_firebase)
                        tostadaCorrutina("Poke: ${ins_nombre} insertado!")

                        val vuelvoaMain=Intent(applicationContext,MainActivity::class.java)
                        startActivity(vuelvoaMain)

                    }

                }
            }


        }

        imagen.setOnClickListener {
            obtener_url.launch("image/*")
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent=Intent(applicationContext,MainActivity::class.java)
        startActivity(intent)
    }

    //==============IMAGEN===================
    private suspend fun insertoImagen(id:String,foto:Uri):String{

        lateinit var urlImagenFirebase:Uri

        urlImagenFirebase= sto_ref.child("Imagenes").child("Pokedex").child(id)
            .putFile(foto).await().storage.downloadUrl.await()

        return urlImagenFirebase.toString()

    }
    //======================================

    fun insertoPokeid(id:String,nombre:String,desc:String,num_poke:Int,rating:Double,fecha:String,url_imagen:String){
        val creo_poke=pokemon(id,nombre,desc,num_poke,rating,fecha,url_imagen)

        db_ref.child(Pokemons).child(Pokedex).child(id).setValue(creo_poke)

    }

    fun compruebo_si_existe(nombre:String):Boolean{
        var existe=false
        val semaforo=CountDownLatch(1)

        db_ref.child(Pokemons).child(Pokedex).orderByChild("nombre").equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if(snapshot.hasChildren()){
                        existe=true
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })
        semaforo.await()
        return existe
    }


    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        when (uri){
            null->Toast.makeText(applicationContext,"No has seleccionado ninguna imagen",Toast.LENGTH_SHORT).show()
            else->{
                url_imagen=uri
                imagen.setImageURI(url_imagen)
                Toast.makeText(applicationContext,"Imagen seleccionada",Toast.LENGTH_SHORT).show()
            }
        }
    }

    //-------HACER UN TOAST EN UNA CORRUTINA------------
    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(applicationContext,texto,Toast.LENGTH_SHORT).show()
        }
    }
//------------------------------------------------------
}