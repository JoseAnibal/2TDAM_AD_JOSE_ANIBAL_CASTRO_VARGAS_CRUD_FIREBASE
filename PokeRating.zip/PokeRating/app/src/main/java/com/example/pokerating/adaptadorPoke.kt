package com.example.pokerating

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import org.w3c.dom.Text
import java.io.Serializable



class adaptadorPoke(val lista:MutableList<pokemon>,val contexto:Context):RecyclerView.Adapter<adaptadorPoke.ViewHolder>() {

    class ViewHolder(v: View):RecyclerView.ViewHolder(v){

        var imagen_Poke:ImageView
        var puntuacion:TextView
        var nombrePoke: TextView
        var num: TextView
        var tipo: TextView
        var fecha:TextView
        var rating:RatingBar
        var eliminar:Button
        var editar:Button


        init {
            imagen_Poke=v.findViewById(R.id.rv_imagen)
            puntuacion=v.findViewById(R.id.rv_puntuacion)
            nombrePoke = v.findViewById(R.id.rv_nombre)
            num = v.findViewById(R.id.rv_num)
            tipo=v.findViewById(R.id.rv_tipo)
            fecha=v.findViewById(R.id.rv_fecha)
            rating=v.findViewById(R.id.rv_ratingbar)

            eliminar=v.findViewById(R.id.rv_eliminar)
            editar=v.findViewById(R.id.rv_editar)
        }

    }



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): adaptadorPoke.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.fila_poke,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: adaptadorPoke.ViewHolder, position: Int) {
        val l = lista[position]

        holder.puntuacion.text="(${l.rating.toString()})"
        holder.nombrePoke.text =l.nombre.toString()
        holder.num.text ="Num: ${l.num_poke.toString()}"
        holder.tipo.text ="Tipo: ${l.desc.toString()}"
        holder.fecha.text =l.fecha
        holder.rating.rating =l.rating!!.toFloat()
        Glide.with(contexto).load(l.url_imagen).into(holder.imagen_Poke)

        holder.eliminar.setOnClickListener {
            val db_ref= FirebaseDatabase.getInstance().getReference()
            val sto_ref= FirebaseStorage.getInstance().getReference()

            sto_ref.child("Imagenes").child("Pokedex").child(l.id!!).delete()
            db_ref.child("Pokemons").child("Pokedex").child(l.id!!).removeValue()

        }

        holder.editar.setOnClickListener {

            val actividad = Intent(contexto,EditarPoke::class.java)
            actividad.putExtra("pasoPokemon", l as Serializable)
            contexto.startActivity (actividad)

        }


    }

    override fun getItemCount(): Int {
        return lista.size
    }
}