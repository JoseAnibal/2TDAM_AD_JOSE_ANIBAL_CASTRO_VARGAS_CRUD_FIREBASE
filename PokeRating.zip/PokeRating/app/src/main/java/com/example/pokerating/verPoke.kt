package com.example.pokerating

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class verPoke : AppCompatActivity() {

    lateinit var rv:RecyclerView

    lateinit var lista:MutableList<pokemon>
    lateinit var db_ref: DatabaseReference
    lateinit var sto_ref: StorageReference
    lateinit var atras:Button

    lateinit var spi:Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ver_poke)
    }

    override fun onStart() {
        super.onStart()

        rv=findViewById(R.id.ver_rv)
        spi=findViewById(R.id.ver_sp)
        atras=findViewById(R.id.ver_btn_atras)

        var orden= listOf(
            "Elige una opcion","Ascendente","Descendente"
        )

        lista= mutableListOf()

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        atras.setOnClickListener {
            val intent=Intent(applicationContext,MainActivity::class.java)
            startActivity(intent)
        }

        db_ref.child("Pokemons")
            .child("Pokedex")
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    lista.clear()
                    snapshot.children.forEach{ hijo: DataSnapshot?->

                        val pojo_club=hijo?.getValue(pokemon::class.java)

                        lista.add(pojo_club!!)
                    }
                    rv.adapter?.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        val adap =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                orden
            )
        adap.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spi.adapter = adap
        spi.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                when(position){
                    0->lista
                    1->lista.sortBy { it.num_poke }
                    2->lista.sortByDescending { it.num_poke }
                }
                rv.adapter?.notifyDataSetChanged()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }

        rv.adapter=adaptadorPoke(lista,this)
        rv.layoutManager= LinearLayoutManager(applicationContext)

    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent= Intent(applicationContext,MainActivity::class.java)
        startActivity(intent)
    }
}